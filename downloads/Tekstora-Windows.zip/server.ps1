$ErrorActionPreference = "SilentlyContinue"
$root = [System.IO.Path]::GetFullPath($PSScriptRoot)
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 8765)
try { $listener.Start() } catch { exit }
while ($true) {
  $client = $null
  try {
    $client = $listener.AcceptTcpClient()
    $client.ReceiveTimeout = 5000
    $stream = $client.GetStream()
    $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
    $line = $reader.ReadLine()
    while ($null -ne ($headerLine = $reader.ReadLine()) -and $headerLine -ne "") {}
    $parts = $line.Split(" ")
    $requested = [System.Uri]::UnescapeDataString($parts[1].Split("?")[0].TrimStart("/"))
    if ([string]::IsNullOrWhiteSpace($requested)) { $requested = "app/index.html" }
    if ($requested.EndsWith("/")) { $requested += "index.html" }
    $file = [System.IO.Path]::GetFullPath((Join-Path $root $requested))
    $prefix = $root.TrimEnd("\") + "\"
    if (-not $file.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $file -PathType Leaf)) {
      $status = "404 Not Found"; $body = [System.Text.Encoding]::UTF8.GetBytes("Not found"); $mime = "text/plain; charset=utf-8"
    } else {
      $status = "200 OK"; $body = [System.IO.File]::ReadAllBytes($file)
      $ext = [System.IO.Path]::GetExtension($file).ToLowerInvariant()
      $mime = switch ($ext) {
        ".html" { "text/html; charset=utf-8" }
        ".js" { "text/javascript; charset=utf-8" }
        ".webmanifest" { "application/manifest+json; charset=utf-8" }
        ".json" { "application/json; charset=utf-8" }
        ".png" { "image/png" }
        ".svg" { "image/svg+xml" }
        default { "application/octet-stream" }
      }
    }
    $responseHeader = "HTTP/1.1 $status`r`nContent-Type: $mime`r`nContent-Length: $($body.Length)`r`nCache-Control: no-cache`r`nConnection: close`r`n`r`n"
    $head = [System.Text.Encoding]::ASCII.GetBytes($responseHeader)
    $stream.Write($head, 0, $head.Length)
    if ($body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }
    $stream.Flush()
  } catch {
  } finally {
    if ($client) { $client.Close() }
  }
}
