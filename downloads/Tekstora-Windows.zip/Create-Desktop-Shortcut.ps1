$target = Join-Path $PSScriptRoot "Start-Tekstora.bat"
$desktop = [Environment]::GetFolderPath("Desktop")
$linkPath = Join-Path $desktop "Tekstora.lnk"
$shell = New-Object -ComObject WScript.Shell
$link = $shell.CreateShortcut($linkPath)
$link.TargetPath = $target
$link.WorkingDirectory = $PSScriptRoot
$link.Description = "Открыть Tekstora — редактор документов"
$link.Save()
Write-Host "Ярлык Tekstora создан на рабочем столе."
